<!DOCTYPE html>
<html>
<head>
	<title>School libraries</title>
	<link rel="stylesheet" type="text/css" href="styling.css">
</head>
<body>
	<header>
		<h1>Welcome to School libraries</h1>
		<nav class="navbar">
		    <img src="logo.png" alt="Logo" class="logo">
			<ul>
				<li><a href="student_home.php">Home</a></li>
				<li><a href="my_loans.php">My loans</a></li>
				<li><a href="my_credentials.php">My credentials</a></li>
			</ul>
		</nav>
	</header>

	<main>

		<section>
			<div class="center-heading">
        		<h2>All the books of our libraries</h2>
    		</div>
   		 <?php
			include 'db_connection.php';
			$conn = OpenCon();

			$query = "SELECT ISBN,title, author_full_name, genres FROM all_books_by_genre";
			$result = mysqli_query($conn, $query);

			if (mysqli_num_rows($result) == 0) {
				echo '<h1 class="error-message">No Books found!</h1>';
			} else {

				echo '<div class="table-responsive">';
				echo '<table class="table">';
				echo '<thead>';
				echo '<tr>';
				echo '<th>Title</th>';
				echo '<th>Author Name</th>';
				echo '<th>Genres</th>';
				echo '<th></th>';
				echo '<th></th>';
				echo '<th></th>'; 
				echo '</tr>';
				echo '</thead>';
				echo '<tbody>';
				while ($row = mysqli_fetch_row($result)) {
					echo '<tr onclick="window.location.href=\'book_details.php?ISBN=' . urlencode($row[0]) . '\'">';
					echo '<td>' . $row[1] . '</td>';
					echo '<td>' . $row[2] . '</td>';
					echo '<td>' . $row[3] . '</td>';
					echo '<td>';
                    echo '<a class="link" href="reserve.php?ISBN=' . urlencode($row[0]) . '">Reserve</a>';
                    
					echo '</td>';
					echo '</tr>';
				}
				echo '</tbody>';
				echo '</table>';
				echo '</div>';
			}
		?>
		</section>

	</main>

    <footer id="site-footer">
        <p>&copy; 2023 School Libraries Site. All rights reserved.</p>
    </footer>
</body>
</html>

