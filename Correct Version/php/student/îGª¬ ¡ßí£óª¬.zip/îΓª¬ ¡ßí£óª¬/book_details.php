<!DOCTYPE html>
<html>
<head>
	<title>School libraries</title>
	<link rel="stylesheet" type="text/css" href="styling.css">
</head>
<body>
	<header>
		<h1>Welcome to School libraries</h1>
        <?php if (!empty($error)) { ?>
            <div class="error-message">
                <?php echo $error; ?>
            </div>
        <?php } ?>
		<nav class="navbar">
		    <img src="logo.png" alt="Logo" class="logo">
			<ul>
                <li><a href="student_home.php">Home</a></li>
				<li><a href="my_loans.php">My loans</a></li>
				<li><a href="my_credentials.php">My credentials</a></li>
			</ul>
		</nav>
	</header>

	<main>

		<section>
			<div class="center-heading">
        		<h2>Book details</h2>
    		</div>
   		 <?php
            session_start();
            if (isset($_SESSION['user_id'])) {
                if (isset($_GET['ISBN'])) {
                    try {
                        include 'db_connection.php';
                        $conn = OpenCon();
                        $ISBN = $_GET['ISBN'];
                        $query = "select * from book where ISBN=$ISBN";
                        $result = mysqli_query($conn, $query);
                        if (mysqli_num_rows($result) > 0) {
                            $book = mysqli_fetch_assoc($result);
                            ?>
                                <section>
                                <div class="book-details">
                                    <img src="<?php echo $book['cover_image']; ?>" alt="Book Cover">
                                    <div class="book-info">
                                    <h2><?php echo $book['title']; ?></h2>
                                    <p><strong>Publisher:</strong> <?php echo $book['publisher']; ?></p>
                                    <p><strong>Page Number:</strong> <?php echo $book['page_number']; ?></p>
                                    <p><strong>Language:</strong> <?php echo $book['book_language']; ?></p>
                                    <p><strong>Summary:</strong> <?php echo $book['summary']; ?></p>
                                    <a class="link" href="reserve.php?ISBN=<?php echo $ISBN; ?>">Reserve</a>
                                    </div>
                                </div>
                                </section>
                            <?php
                         } else {
                            $error = "An error occurred.";
                            header("Location: student_home.php?error=" . urlencode($error));
                            exit();
                        }
                    } catch (Exception $e) {
                        $error = "Error: " . $e->getMessage();
                        header("Location: student_home.php?error=" . urlencode($error));
                        exit();
                    }
                } else {
                    $error = "ISBN not found.";
                    header("Location: student_home.php?error=" . urlencode($error));
                    exit();
                }
            } else {
            $error="Connection error.";
            }
		?>
		</section>

	</main>

    <footer id="site-footer">
        <p>&copy; 2023 School Libraries Site. All rights reserved.</p>
    </footer>
</body>
</html>
