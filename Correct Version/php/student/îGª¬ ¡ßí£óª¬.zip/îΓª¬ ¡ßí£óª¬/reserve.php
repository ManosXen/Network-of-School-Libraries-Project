<?php
session_start();
if (isset($_SESSION['user_id'])) {
    if (isset($_GET['ISBN'])) {
        try {
            $userID = $_SESSION['user_id'];
            include 'db_connection.php';
            $conn = OpenCon();
            $ISBN = $_GET['ISBN'];
            $query = "INSERT INTO loan (request_date, loan_status, last_status_update, loan_date, return_date, user_id, ISBN)
                      VALUES (NOW(), 'pending', NOW(), NULL, NULL, $userID, '$ISBN')";
            if (mysqli_query($conn, $query)) {
                header("Location: my_loans.php");
                exit();
            } else {
                $error = "An error occurred.";
                header("Location: my_loans.php?error=" . urlencode($error));
                exit();
            }
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
            header("Location: my_loans.php?error=" . urlencode($error));
            exit();
        }
    } else {
        $error = "ISBN not found.";
        header("Location: my_loans.php?error=" . urlencode($error));
        exit();
    }
} else {
    echo "User ID not found.";
}
?>
