<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
	<link rel="stylesheet" type="text/css" href="styling.css">
</head>
<body>
	<div class="login-box">
		<div class="form">
			<h1>Change Password</h1>
			<form class="login-form">
				<input type="text" placeholder="Username" required/>
				<button class="login-button">Change Password</button>
			</form>
		</div>
	</div>
</body>
</html>
